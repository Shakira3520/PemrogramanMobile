from django.apps import AppConfig


class PerpustakaanConfig(AppConfig):
    name = 'perpustakaan'
